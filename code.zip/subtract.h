#ifndef SUBTRACT_H
  #define SUBTRACT_H
  extern int subtract(int a, int b);
#endif
